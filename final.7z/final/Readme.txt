Import all Java maven project in eclipse. Angular project in VSCode.

Database: Only for illustration i have used H2 db in disk based mode.

1. Eureka-server  project(Registry eureka server)
	clean build:
		mvn clean package
	start application:
		run as java application / mvn spring-boot:run -DskipTests
	This is our registry
	url: http://localhost:8761
	
2. Eureka-services  project(Microservice eureka client)
	clean build:
		mvn clean package
	start application:
		run as java application / mvn spring-boot:run -DskipTests
	This is our microservice
	url: http://localhost:8180
	
3. Circuitbreaker-services  project(Hystrix)
	clean build:
		mvn clean package
	start application:
		run as java application / mvn spring-boot:run -DskipTests
	This is our Circuit breaker
	url: http://localhost:8090
	
4. gateway-service  project (Gateway Zuul)
	clean build:
		mvn clean package
	start application:
		run as java application / mvn spring-boot:run -DskipTests
	This is our gateway
	url: http://localhost:8080
	
5. covid-app  project(Angular 9)
	npm install to install dependencies
	npm start to start ui.
	This is our angular ui.
	url: http://localhost:4200
	Open this in browser.
	
I have applied the microservices architechure. 
The circuit breaker is also working if you turn down the Eureka-services microservice, 
it would give a generic fallback message and it is gracefully handled in ui(Angular) too with message we are still calculating.
Also attached screenshot of the application.
