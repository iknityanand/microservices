import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { navbarRoute } from './layouts/navbar/navbar.route';
import { footerRoute } from './layouts/footer/footer.route';

const routes: Routes = [navbarRoute, footerRoute];

@NgModule({
  imports: [
    RouterModule.forRoot([
      ...routes,
      {
        path: '', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule)
      },
      { path: '**', redirectTo: '', }
    ], {
      useHash: true
    })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
