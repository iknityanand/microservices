import { HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { DashboardService } from './dashboard.service';

@Injectable({ providedIn: 'root' })
export class DashboardResolve implements Resolve<any> {

  constructor(private dashboardService: DashboardService) { }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {

    return this.dashboardService.getAllData().pipe(
      filter((response: HttpResponse<any>) => response.ok),
      map((allData: HttpResponse<any>) => allData.body)
    )
  }
}
