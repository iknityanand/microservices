import { Component, OnInit } from '@angular/core';
import { DashboardService } from './dashboard.service';
import { faEye, faHeart, faHeartBroken } from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  _allCountries: any;
  _country: any;
  data: any;
  faEye = faEye;
  faHeart = faHeart;
  faHeartBroken = faHeartBroken;
  constructor(private dashboardService: DashboardService, protected activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(data => {
      this._country = data.loadDashboardState;
    });

    this.getAllCountries();
  }

  getAll() {
    this.dashboardService.getAllData().subscribe(data => {
      this._country = data.body;
    });
  }

  getAllCountries() {
    this.dashboardService.getAllCountries().subscribe(data => {
      this._allCountries = data.body.map(countrywise => {
        return countrywise.country;
      });
    });
  }

  changeModel(e: any): void {
    const country = e;
    this.dashboardService.getCountry(country).subscribe(data => {
      this._country = data.body;
    });
  }

}
