import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SERVER_API_URL } from '../app.constant';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  public resourceUrl = SERVER_API_URL + '/api/';
  // public resourceUrl = SERVER_API_URL;
  constructor(private http: HttpClient) {}

  getAllData(): Observable<HttpResponse<any>> {
    return this.http.get(this.resourceUrl + 'status', { observe: 'response' });
  }

  getAllCountries(): Observable<HttpResponse<any>> {
    return this.http.get(this.resourceUrl + 'countries/all', { observe: 'response' });
  }

  getCountry(countryName: string): Observable<HttpResponse<any>> {
    return this.http.get(`${this.resourceUrl}countries/${countryName}`, { observe: 'response' });
  }

  getAllHistorical(): Observable<HttpResponse<any>> {
    return this.http.get(this.resourceUrl + 'historical', { observe: 'response' });
  }

  getHistoricalByCountry(countryName: string): Observable<HttpResponse<any>> {
    return this.http.get(`${this.resourceUrl}historical/${countryName}`, { observe: 'response' });
  }
}
