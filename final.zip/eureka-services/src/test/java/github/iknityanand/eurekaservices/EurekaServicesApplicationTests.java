package github.iknityanand.eurekaservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
