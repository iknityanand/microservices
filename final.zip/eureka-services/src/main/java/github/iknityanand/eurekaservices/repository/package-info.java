/**
 * Spring Data JPA repositories.
 */
/**
 * @author iknityanand
 *
 */
package github.iknityanand.eurekaservices.repository;