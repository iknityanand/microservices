/**
 * Service layer beans.
 */
/**
 * @author iknityanand
 *
 */
package github.iknityanand.eurekaservices.service;