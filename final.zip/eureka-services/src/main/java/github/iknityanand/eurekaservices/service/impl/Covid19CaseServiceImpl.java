package github.iknityanand.eurekaservices.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import github.iknityanand.eurekaservices.domain.Covid19Case;
import github.iknityanand.eurekaservices.domain.Endpoints;
import github.iknityanand.eurekaservices.domain.Historical;
import github.iknityanand.eurekaservices.service.Covid19CaseService;
/**
 * Service Implementation for managing {@link Endpoints}.
 */
@Service
@Transactional
public class Covid19CaseServiceImpl implements Covid19CaseService {
	
	@Autowired
	RestTemplate restTemplate;

	@Override
	public Covid19Case getAllStatus() {
		HttpHeaders requestHeaders = new HttpHeaders();
        HttpEntity<?> requestEntity = new HttpEntity<>(requestHeaders);

        ResponseEntity<Covid19Case> responseEntity = restTemplate.exchange("https://corona.lmao.ninja/all",
                HttpMethod.GET,
                requestEntity,
                Covid19Case.class);
        return responseEntity.getBody();
	}

	@Override
	public String getAllCountries() {
		HttpHeaders requestHeaders = new HttpHeaders();
        HttpEntity<?> requestEntity = new HttpEntity<>(requestHeaders);

        ResponseEntity<String> responseEntity = restTemplate.exchange("https://corona.lmao.ninja/countries",
                HttpMethod.GET,
                requestEntity,
                String.class);
        return responseEntity.getBody();
	}

	@Override
	public Covid19Case getByCountryName(String countryName) {
		// https://corona.lmao.ninja/countries/{country-name}
        HttpHeaders requestHeaders = new HttpHeaders();
        HttpEntity<?> requestEntity = new HttpEntity<>(requestHeaders);

        ResponseEntity<Covid19Case> responseEntity = restTemplate.exchange("https://corona.lmao.ninja/countries/" + countryName,
                HttpMethod.GET,
                requestEntity,
                Covid19Case.class);
        return responseEntity.getBody();
	}

	@Override
	public String getAllHistorical() {
		HttpHeaders requestHeaders = new HttpHeaders();
        HttpEntity<?> requestEntity = new HttpEntity<>(requestHeaders);

        ResponseEntity<String> responseEntity = restTemplate.exchange("https://corona.lmao.ninja/v2/historical",
                HttpMethod.GET,
                requestEntity,
                String.class);
        return responseEntity.getBody();
	}

	@Override
	public Historical getHistoricalByCountryName(String countryName) {
        HttpHeaders requestHeaders = new HttpHeaders();
        HttpEntity<?> requestEntity = new HttpEntity<>(requestHeaders);

        ResponseEntity<Historical> responseEntity = restTemplate.exchange("https://corona.lmao.ninja/v2/historical/" + countryName,
                HttpMethod.GET,
                requestEntity,
                Historical.class);
        return responseEntity.getBody();
	}

}
