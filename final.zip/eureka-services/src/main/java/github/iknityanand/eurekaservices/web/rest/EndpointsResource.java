package github.iknityanand.eurekaservices.web.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import github.iknityanand.eurekaservices.domain.Endpoints;
import github.iknityanand.eurekaservices.service.EndpointsService;

/**
 * REST controller for managing {@link github.iknityanand.eurekaservices.domain.Endpoints}.
 */
@RestController
@RequestMapping("/api")
public class EndpointsResource {

    private final Logger log = LoggerFactory.getLogger(EndpointsResource.class);

    private final EndpointsService endpointsService;

    public EndpointsResource(EndpointsService endpointsService) {
        this.endpointsService = endpointsService;
    }
    
    @GetMapping("/endpoints")
    public List<Endpoints> getAllEndpoints() {
        log.debug("REST request to get all Endpoints");
        return endpointsService.findAll();
    }
}
