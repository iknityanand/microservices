/**
 * Spring Framework configuration files.
 */
/**
 * @author c-NityanandK
 *
 */
package github.iknityanand.eurekaservices.config;