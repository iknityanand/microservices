package github.iknityanand.eurekaservices.repository;

import github.iknityanand.eurekaservices.domain.Endpoints;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the Endpoints entity.
 */
@SuppressWarnings("unused")
@Repository
public interface EndpointsRepository extends JpaRepository<Endpoints, Long> {
}
