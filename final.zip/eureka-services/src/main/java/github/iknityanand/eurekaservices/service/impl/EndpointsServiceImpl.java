package github.iknityanand.eurekaservices.service.impl;

import github.iknityanand.eurekaservices.service.EndpointsService;
import github.iknityanand.eurekaservices.domain.Endpoints;
import github.iknityanand.eurekaservices.repository.EndpointsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing {@link Endpoints}.
 */
@Service
@Transactional
public class EndpointsServiceImpl implements EndpointsService {

    private final Logger log = LoggerFactory.getLogger(EndpointsServiceImpl.class);

    private final EndpointsRepository endpointsRepository;

    public EndpointsServiceImpl(EndpointsRepository endpointsRepository) {
        this.endpointsRepository = endpointsRepository;
    }

    /**
     * Save a endpoints.
     *
     * @param endpoints the entity to save.
     * @return the persisted entity.
     */
    @Override
    public Endpoints save(Endpoints endpoints) {
        log.debug("Request to save Endpoints : {}", endpoints);
        return endpointsRepository.save(endpoints);
    }

    /**
     * Get all the endpoints.
     *
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public List<Endpoints> findAll() {
        log.debug("Request to get all Endpoints");
        return endpointsRepository.findAll();
    }

    /**
     * Get one endpoints by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<Endpoints> findOne(Long id) {
        log.debug("Request to get Endpoints : {}", id);
        return endpointsRepository.findById(id);
    }

    /**
     * Delete the endpoints by id.
     *
     * @param id the id of the entity.
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Endpoints : {}", id);
        endpointsRepository.deleteById(id);
    }
}
