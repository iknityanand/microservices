package github.iknityanand.eurekaservices.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashMap;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author iknityanand
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Historical implements Serializable {

    @JsonAlias("country")
    @JsonProperty("country")
    private String country;

    @JsonAlias("timeline")
    @JsonProperty("timeline")
    private Timeline timeline;

}
