package github.iknityanand.eurekaservices.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashMap;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author iknityanand
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Timeline implements Serializable {

    @JsonAlias("cases")
    @JsonProperty("cases")
    private LinkedHashMap<String, Long> cases;

    @JsonAlias("deaths")
    @JsonProperty("deaths")
    private LinkedHashMap<String, Long> deaths;

}
