package github.iknityanand.eurekaservices.web.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import github.iknityanand.eurekaservices.service.Covid19CaseService;

/**
 * REST controller for managing
 * {@link github.iknityanand.eurekaservices.domain.Covid19Case}.
 */
@RestController
@RequestMapping("/api")
public class Covid19Resource {

	@Autowired
	Covid19CaseService covid19CaseService;

	@GetMapping(value = "/status", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllStatus() {
		return new ResponseEntity<>(covid19CaseService.getAllStatus(), HttpStatus.OK);
	}

	@GetMapping(value = "/countries/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllCountries() {
		return new ResponseEntity<>(covid19CaseService.getAllCountries(), HttpStatus.OK);
	}

	@GetMapping(value = "/countries/{countryName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getByCountryName(@PathVariable("countryName") String countryName) {
		return new ResponseEntity<>(covid19CaseService.getByCountryName(countryName), HttpStatus.OK);
	}

	@GetMapping(value = "/historical", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllHistorical() {
		return new ResponseEntity<>(covid19CaseService.getAllHistorical(), HttpStatus.OK);
	}

	@GetMapping(value = "/historical/{countryName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getHistoricalByCountryName(@PathVariable("countryName") String countryName) {
		return new ResponseEntity<>(covid19CaseService.getHistoricalByCountryName(countryName), HttpStatus.OK);
	}

}
