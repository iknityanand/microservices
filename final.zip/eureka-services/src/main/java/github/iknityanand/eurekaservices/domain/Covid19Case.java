package github.iknityanand.eurekaservices.domain;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author iknityanand
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Covid19Case implements Serializable {
	
	@JsonAlias("country")
    @JsonProperty("country")
	private String country;

	@JsonAlias("countryInfo")
    @JsonProperty("countryInfo")
	private CountryInfo countryInfo;

	@JsonAlias("cases")
    @JsonProperty("cases")
	private Integer cases;

	@JsonAlias("totalCases")
    @JsonProperty("totalCases")
	private Integer totalCases;

	@JsonAlias("deaths")
    @JsonProperty("deaths")
	private Integer deaths;

	@JsonAlias("totalDeaths")
    @JsonProperty("totalDeaths")
	private Integer totalDeaths;

	@JsonAlias("recovered")
    @JsonProperty("recovered")
	private Integer recovered;

	@JsonAlias("active")
    @JsonProperty("active")
	private Integer active;

	@JsonAlias("critical")
    @JsonProperty("critical")
	private Integer critical;

	@JsonAlias("casesPerOneMillion")
    @JsonProperty("casesPerOneMillion")
	private Double casesPerOneMillion;

	@JsonAlias("deathsPerOneMillion")
    @JsonProperty("deathsPerOneMillion")
	private Integer deathsPerOneMillion;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "America/Chicago")
	private Date updated;
	
	

}