/**
 * JPA domain objects.
 */
/**
 * @author iknityanand
 *
 */
package github.iknityanand.eurekaservices.domain;