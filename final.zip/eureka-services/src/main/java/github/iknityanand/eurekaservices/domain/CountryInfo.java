package github.iknityanand.eurekaservices.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author iknityanand
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CountryInfo implements Serializable {

    @JsonAlias("_id")
    @JsonProperty("id")
    private Integer id;

    @JsonAlias("lat")
    @JsonProperty("latitude")
    private Integer latitude;

    @JsonAlias("long")
    @JsonProperty("longitude")
    private Integer longitude;

    @JsonAlias("flag")
    @JsonProperty("flag")
    private String flag;

    @JsonAlias("iso2")
    @JsonProperty("iso2")
    private String iso2;

    @JsonAlias("iso3")
    @JsonProperty("iso3")
    private String iso3;
}