/**
 * Spring MVC REST controllers.
 */
/**
 * @author iknityanand
 *
 */
package github.iknityanand.eurekaservices.web.rest;