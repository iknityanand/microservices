package github.iknityanand.eurekaservices.service;

import github.iknityanand.eurekaservices.domain.Covid19Case;
import github.iknityanand.eurekaservices.domain.Historical;

/**
 * Service Interface for managing {@link Covid19Case}.
 */
public interface Covid19CaseService {
	/**
     * Returns all total cases, recovery and deaths.
     * @return Single JSON String
     */
    Covid19Case getAllStatus();

    /**
     * Returns data of all countries that has COVID-19 cases
     * @return List of JSON Strings
     */
    String getAllCountries();

    /**
     * Returns data of a specific country.
     * @param countryName String value
     * @return JSON String
     */
    Covid19Case getByCountryName(String countryName);

    /**
     * Returns historical data of all countries that has COVID-19 cases
     * @return List of JSON Strings
     */
    String getAllHistorical();

    /**
     * Returns historical data of a specific country.
     * @param countryName String value
     * @return JSON String
     */
    Historical getHistoricalByCountryName(String countryName);
}
