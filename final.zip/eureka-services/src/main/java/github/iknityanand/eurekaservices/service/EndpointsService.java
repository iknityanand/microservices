package github.iknityanand.eurekaservices.service;

import github.iknityanand.eurekaservices.domain.Endpoints;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link Endpoints}.
 */
public interface EndpointsService {

    /**
     * Save a endpoints.
     *
     * @param endpoints the entity to save.
     * @return the persisted entity.
     */
    Endpoints save(Endpoints endpoints);

    /**
     * Get all the endpoints.
     *
     * @return the list of entities.
     */
    List<Endpoints> findAll();

    /**
     * Get the "id" endpoints.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<Endpoints> findOne(Long id);

    /**
     * Delete the "id" endpoints.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
