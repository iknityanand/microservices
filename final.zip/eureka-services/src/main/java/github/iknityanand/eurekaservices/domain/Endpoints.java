package github.iknityanand.eurekaservices.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * A Endpoints.
 */
@Entity
@Table(name = "endpoints")
public class Endpoints implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "apiurl")
	private String apiurl;

	@Column(name = "description")
	private String description;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getApiurl() {
		return apiurl;
	}

	public Endpoints apiurl(String apiurl) {
		this.apiurl = apiurl;
		return this;
	}

	public void setApiurl(String apiurl) {
		this.apiurl = apiurl;
	}

	public String getDescription() {
		return description;
	}

	public Endpoints description(String description) {
		this.description = description;
		return this;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof Endpoints)) {
			return false;
		}
		return id != null && id.equals(((Endpoints) o).id);
	}

	@Override
	public int hashCode() {
		return 31;
	}

	@Override
	public String toString() {
		return "Endpoints{" + "id=" + getId() + ", apiurl='" + getApiurl() + "'" + ", description='" + getDescription()
				+ "'" + "}";
	}
}
