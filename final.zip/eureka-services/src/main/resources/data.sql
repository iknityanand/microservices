DROP TABLE IF EXISTS endpoints;
 
CREATE TABLE endpoints (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  apiurl VARCHAR(250) NOT NULL,
  description VARCHAR(250) NOT NULL
);
 
INSERT INTO endpoints (apiurl, description) VALUES
  ('https://corona.lmao.ninja/all', 'Returns all total cases, recovery, and deaths.'),
  ('https://corona.lmao.ninja/countries', 'Returns data of all countries that has COVID-19'),
  ('https://corona.lmao.ninja/historical', 'Get historical data');