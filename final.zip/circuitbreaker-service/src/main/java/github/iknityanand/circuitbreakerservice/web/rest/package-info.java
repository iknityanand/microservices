/**
 * Spring MVC REST controllers.
 */
/**
 * @author iknityanand
 *
 */
package github.iknityanand.circuitbreakerservice.web.rest;