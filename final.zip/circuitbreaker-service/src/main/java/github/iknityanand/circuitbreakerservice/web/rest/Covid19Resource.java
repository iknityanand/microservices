package github.iknityanand.circuitbreakerservice.web.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import github.iknityanand.circuitbreakerservice.service.Covid19Service;

/**
 * REST controller for managing
 * {@link github.iknityanand.eurekaservices.domain.Covid19Case}.
 */
@RestController
@RequestMapping("/api")
public class Covid19Resource {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	Covid19Service covid19Service;

	@GetMapping(value = "/status", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllStatus() {
		return new ResponseEntity<>(covid19Service.getAllStatus(), HttpStatus.OK);
	}

	@GetMapping(value = "/countries/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllCountries() {
		return new ResponseEntity<>(covid19Service.getAllCountries(), HttpStatus.OK);
	}

	@GetMapping(value = "/countries/{countryName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getByCountryName(@PathVariable("countryName") String countryName) {
		return new ResponseEntity<>(covid19Service.getByCountryName(countryName), HttpStatus.OK);
	}

	@GetMapping(value = "/historical", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllHistorical() {
		return new ResponseEntity<>(covid19Service.getAllHistorical(), HttpStatus.OK);
	}

	@GetMapping(value = "/historical/{countryName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getHistoricalByCountryName(@PathVariable("countryName") String countryName) {
		return new ResponseEntity<>(covid19Service.getHistoricalByCountryName(countryName), HttpStatus.OK);
	}

}
