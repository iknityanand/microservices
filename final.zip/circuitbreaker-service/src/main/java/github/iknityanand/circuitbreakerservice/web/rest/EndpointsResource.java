package github.iknityanand.circuitbreakerservice.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("/circuitbreaker")
public class EndpointsResource {

	private static final Logger log = LoggerFactory.getLogger(EndpointsResource.class);

	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/endpoints")
	@HystrixCommand(fallbackMethod = "handleFallback")
	public String endpoints() {
		return restTemplate.getForObject("http://eureka-service/api/endpoints", String.class);
	}

	public String handleFallback() {
		return "Fallback hello service";
	}

}
