/**
 * Spring Framework configuration files.
 */
/**
 * @author iknityanand
 *
 */
package github.iknityanand.circuitbreakerservice.config;