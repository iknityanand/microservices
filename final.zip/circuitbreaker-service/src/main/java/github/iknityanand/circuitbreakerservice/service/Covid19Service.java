package github.iknityanand.circuitbreakerservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class Covid19Service {

	@Autowired
	RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "handleFallback")
	public String getAllStatus() {
		return restTemplate.getForObject("http://eureka-service/api/status", String.class);
	}

	@HystrixCommand(fallbackMethod = "handleFallback")
	public String getAllCountries() {
		return restTemplate.getForObject("http://eureka-service/api/countries/all", String.class);
	}

	@HystrixCommand(fallbackMethod = "handleFallback")
	public String getByCountryName(String countryName) {
		return restTemplate.getForObject("http://eureka-service/api/countries/{countryName}", String.class, countryName);
	}

	@HystrixCommand(fallbackMethod = "handleFallback")
	public String getAllHistorical() {
		return restTemplate.getForObject("http://eureka-service/api/historical", String.class);
	}

	@HystrixCommand(fallbackMethod = "handleFallback")
	public String getHistoricalByCountryName(String countryName) {
		return restTemplate.getForObject("http://eureka-service/api/historical/{countryName}", String.class, countryName);
	}

	public String handleFallback() {
		return "{\"message\":\"We are still calculating\"}";
	}

	public String handleFallback(String countryName) {
		return "{\"message\":\"We are still calculating for your country\"}";
	}
}
